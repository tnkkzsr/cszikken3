
def remove_line_numbers_and_convert_quotes(input_text):
    output_lines = []
    for line in input_text.split('\n'):
        # 行頭の数字とスペースを削除
        stripped_line = line.lstrip('0123456789 ')
        # 右シングルクォーテーションを左シングルクォーテーションに変換
        converted_line = stripped_line.replace('’', "'")
        output_lines.append(converted_line)
    return '\n'.join(output_lines)

# 入力テキスト
input_text = """
1 #!/usr/bin/env python
2 # -*- coding: utf-8 -*-
3
4 import sys
5
6 import ply.lex as lex
7 import ply.yacc as yacc
8
9 from symtab import Scope, Symbol, SymbolTable
10 from fundef import Fundef
11 from llvmcode import *
12 from operand import OType, Operand
13
14 ## トークン名のリスト
15 tokens = (
16 ’BEGIN’, ’DIV’, ’DO’, ’ELSE’, ’END’, ’FOR’, ’FUNCTION’, ’IF’,
17 ’PROCEDURE’, ’PROGRAM’, ’READ’, ’THEN’, ’TO’, ’VAR’, ’WHILE’, ’WRITE’,
18 ’PLUS’, ’MINUS’, ’MULT’, ’EQ’, ’NEQ’, ’LT’, ’LE’, ’GT’, ’GE’,
19 ’LPAREN’, ’RPAREN’, ’LBRACKET’, ’RBRACKET’, ’COMMA’, ’SEMICOLON’,
20 ’PERIOD’, ’INTERVAL’, ’ASSIGN’,
21 ’IDENT’, ’NUMBER’
22 )
23
24 ## 予約語の定義
25 reserved = {
26 ’begin’: ’BEGIN’,
27 ’div’: ’DIV’,
28 ’do’: ’DO’,
29 ’else’: ’ELSE’,
30 ’end’: ’END’,
31 ’for’: ’FOR’,
32 ’function’: ’FUNCTION’,
33 ’if’: ’IF’,
34 ’procedure’: ’PROCEDURE’,
35 ’program’: ’PROGRAM’,
36 ’read’: ’READ’,
37 ’then’: ’THEN’,
38 ’to’: ’TO’,
39 ’var’: ’VAR’,
"""

# 行番号とスペースを取り除く
output_text = remove_line_numbers(input_text)

print(output_text)